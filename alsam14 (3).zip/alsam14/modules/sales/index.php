    if (customerSelect) {
        customerSelect.addEventListener('change', syncCustomerMarketer);
    }

    if (marketerSelect) {
        marketerSelect.addEventListener('change', function () {
            syncSaleMode();
            syncQuickCustomerMarketer();
        });
        syncSaleMode();
        syncQuickCustomerMarketer();
    }

    // عميل سريع - إضافة الحدث لزر الإظهار والإخفاء
    const toggleQuickCustomerBtn = document.querySelector('[data-toggle-customer-quick-form]');
    const closeQuickCustomerBtn = document.querySelector('[data-close-customer-quick-form]');
    const quickCustomerPanel = document.querySelector('[data-customer-quick-panel]');
    const saveQuickCustomerBtn = document.querySelector('[data-save-quick-customer]');

    if (toggleQuickCustomerBtn && quickCustomerPanel) {
        toggleQuickCustomerBtn.addEventListener('click', function () {
            quickCustomerPanel.hidden = false;
            syncQuickCustomerMarketer();
            const nameInput = quickCustomerPanel.querySelector('[name="quick_customer_full_name"]');
            if (nameInput) nameInput.focus();
        });
    }

    if (closeQuickCustomerBtn && quickCustomerPanel) {
        closeQuickCustomerBtn.addEventListener('click', function () {
            quickCustomerPanel.hidden = true;
        });
    }

    // حفظ العميل السريع
    if (saveQuickCustomerBtn && quickCustomerPanel) {
        saveQuickCustomerBtn.addEventListener('click', function () {
            const fullNameInput = quickCustomerPanel.querySelector('[name="quick_customer_full_name"]');
            const phoneInput = quickCustomerPanel.querySelector('[name="quick_customer_phone"]');
            const categoryInput = quickCustomerPanel.querySelector('[name="quick_customer_category"]');
            const creditLimitInput = quickCustomerPanel.querySelector('[name="quick_customer_credit_limit"]');

            if (!fullNameInput || !fullNameInput.value.trim()) {
                alert('أدخل اسم العميل');
                if (fullNameInput) fullNameInput.focus();
                return;
            }

            const formData = new FormData();
            formData.append('quick_create', '1');
            formData.append('full_name', fullNameInput.value.trim());
            formData.append('phone', phoneInput ? phoneInput.value.trim() : '');
            formData.append('category', categoryInput ? categoryInput.value.trim() : '');
            formData.append('credit_limit', creditLimitInput ? creditLimitInput.value : '0');
            
            const marketerId = marketerSelect ? marketerSelect.value : '';
            formData.append('marketer_id', marketerId);
            
            const branchId = document.querySelector('[name="branch_id"]')?.value || '';
            formData.append('branch_id', branchId);
            formData.append('status', 'active');
            formData.append('_token', document.querySelector('[name="_token"]')?.value || '');

            saveQuickCustomerBtn.disabled = true;
            const originalText = saveQuickCustomerBtn.textContent;
            saveQuickCustomerBtn.textContent = 'جاري الحفظ...';

            fetch('ajax/customers/save.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    if (customerSelect) {
                        const option = document.createElement('option');
                        option.value = result.data.id;
                        option.textContent = result.data.full_name;
                        option.setAttribute('data-marketer-id', result.data.marketer_id || '');
                        option.selected = true;
                        customerSelect.appendChild(option);
                        customerSelect.value = result.data.id;
                        customerSelect.dispatchEvent(new Event('change'));
                    }
                    quickCustomerPanel.hidden = true;
                    fullNameInput.value = '';
                    if (phoneInput) phoneInput.value = '';
                    if (categoryInput) categoryInput.value = '';
                    if (creditLimitInput) creditLimitInput.value = '0';
                    alert('تم إضافة العميل بنجاح');
                } else {
                    alert(result.message || 'حدث خطأ أثناء حفظ العميل');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('حدث خطأ أثناء الاتصال بالخادم: ' + error.message);
            })
            .finally(() => {
                saveQuickCustomerBtn.disabled = false;
                saveQuickCustomerBtn.textContent = originalText;
            });
        });
    }