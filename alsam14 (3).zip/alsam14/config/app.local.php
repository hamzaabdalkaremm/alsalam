<?php

return [
    'debug' => true,
];
